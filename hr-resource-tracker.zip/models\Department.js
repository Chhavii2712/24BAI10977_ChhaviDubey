const mongoose = require('mongoose');

const departmentSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Please add a department name'],
        unique: true,
        trim: true
    },
    location: {
        type: String,
        required: [true, 'Please add a location']
    }
}, {
    timestamps: true
});

module.exports = mongoose.model('Department', departmentSchema);
