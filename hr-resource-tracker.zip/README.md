# HR Resource & Project Tracker

A backend application that manages HR resources, tracks employee profiles, and assigns projects. The system demonstrates native NoSQL MongoDB architecture implementing One-to-One, One-to-Many, and Many-to-Many data relationships.

## Tech Stack
- **Backend Runtime**: Node.js
- **Framework**: Express.js
- **Database**: MongoDB (Mongoose ODM)
- **API Documentation**: swagger-ui-express, swagger-jsdoc

## Features
- Full CRUD operations across Departments, Profiles, Projects, and Employees.
- Mongoose schema references (ObjectId + ref) implementing One-to-One, One-to-Many, and Many-to-Many relationships.
- Interactive Swagger API documentation.

## Setup Instructions

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Environment Variables:**
   Create a `.env` file in the root directory and add the following:
   ```env
   PORT=5000
   MONGO_URI=mongodb://127.0.0.1:27017/hr-resource-tracker
   ```
   Ensure you have a MongoDB instance running locally or update the connection string to your MongoDB Atlas cluster.

3. **Run the Application:**
   ```bash
   npm run dev
   ```
   The server will start on port `5000` (or whatever you set in `.env`).

## API Documentation
Once the server is running, you can access the interactive Swagger UI at:
```
http://localhost:5000/api-docs
```

## Screenshots

Below are the screenshots of the interactive Swagger API documentation running locally:

### 1. Projects and Profiles APIs
![Projects and Profiles APIs](assets/ss1.png)

### 2. Departments APIs
![Departments APIs](assets/ss2.png)

### 3. Executing GET /api/projects
![Executing GET /api/projects](assets/ss3.png)

### 4. Response of GET /api/projects
![Response of GET /api/projects](assets/ss4.png)
