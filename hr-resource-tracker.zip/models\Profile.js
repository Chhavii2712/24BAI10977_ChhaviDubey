const mongoose = require('mongoose');

const profileSchema = new mongoose.Schema({
    title: {
        type: String,
        required: [true, 'Please add a job title']
    },
    salary: {
        type: Number,
        required: [true, 'Please add a salary']
    },
    joinDate: {
        type: Date,
        default: Date.now
    }
}, {
    timestamps: true
});

module.exports = mongoose.model('Profile', profileSchema);
