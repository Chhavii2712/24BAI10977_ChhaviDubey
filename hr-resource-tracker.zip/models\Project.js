const mongoose = require('mongoose');

const projectSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Please add a project name'],
        unique: true,
        trim: true
    },
    description: {
        type: String,
        required: [true, 'Please add a description']
    },
    status: {
        type: String,
        enum: ['Planning', 'Active', 'Completed', 'On Hold'],
        default: 'Planning'
    }
}, {
    timestamps: true
});

module.exports = mongoose.model('Project', projectSchema);
