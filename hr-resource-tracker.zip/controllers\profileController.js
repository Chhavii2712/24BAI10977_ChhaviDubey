const Profile = require('../models/Profile');

exports.getProfiles = async (req, res) => {
    try {
        const profiles = await Profile.find();
        res.status(200).json({ success: true, data: profiles });
    } catch (err) {
        res.status(500).json({ success: false, error: 'Server Error' });
    }
};

exports.getProfile = async (req, res) => {
    try {
        const profile = await Profile.findById(req.params.id);
        if (!profile) {
            return res.status(404).json({ success: false, error: 'Profile not found' });
        }
        res.status(200).json({ success: true, data: profile });
    } catch (err) {
        res.status(500).json({ success: false, error: 'Server Error' });
    }
};

exports.createProfile = async (req, res) => {
    try {
        const profile = await Profile.create(req.body);
        res.status(201).json({ success: true, data: profile });
    } catch (err) {
        res.status(400).json({ success: false, error: err.message });
    }
};

exports.updateProfile = async (req, res) => {
    try {
        const profile = await Profile.findByIdAndUpdate(req.params.id, req.body, {
            new: true,
            runValidators: true
        });
        if (!profile) {
            return res.status(404).json({ success: false, error: 'Profile not found' });
        }
        res.status(200).json({ success: true, data: profile });
    } catch (err) {
        res.status(400).json({ success: false, error: err.message });
    }
};

exports.deleteProfile = async (req, res) => {
    try {
        const profile = await Profile.findByIdAndDelete(req.params.id);
        if (!profile) {
            return res.status(404).json({ success: false, error: 'Profile not found' });
        }
        res.status(200).json({ success: true, data: {} });
    } catch (err) {
        res.status(500).json({ success: false, error: 'Server Error' });
    }
};
