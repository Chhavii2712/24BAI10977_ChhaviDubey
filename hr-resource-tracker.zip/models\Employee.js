const mongoose = require('mongoose');

const employeeSchema = new mongoose.Schema({
    firstName: {
        type: String,
        required: [true, 'Please add a first name']
    },
    lastName: {
        type: String,
        required: [true, 'Please add a last name']
    },
    email: {
        type: String,
        required: [true, 'Please add an email'],
        unique: true,
        match: [
            /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/,
            'Please add a valid email'
        ]
    },
    department: {
        type: mongoose.Schema.ObjectId,
        ref: 'Department',
        required: true
    },
    profile: {
        type: mongoose.Schema.ObjectId,
        ref: 'Profile',
        required: true
    },
    projects: [{
        type: mongoose.Schema.ObjectId,
        ref: 'Project'
    }]
}, {
    timestamps: true
});

module.exports = mongoose.model('Employee', employeeSchema);
